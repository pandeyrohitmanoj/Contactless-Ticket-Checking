package com.projects.ticket_checker;

import com.journeyapps.barcodescanner.CaptureActivity;

public class capture extends CaptureActivity {
}
